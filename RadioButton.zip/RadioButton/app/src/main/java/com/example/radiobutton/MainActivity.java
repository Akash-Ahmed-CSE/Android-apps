package com.example.radiobutton;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.EmptyStackException;


public class MainActivity extends AppCompatActivity {
    EditText e1;
    RadioButton ru,rc;
    TextView tvresult;
    Button btnConvert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 =(EditText) findViewById(R.id.Ebdt);
        ru=(RadioButton)findViewById(R.id.rbUSD);
        rc=(RadioButton)findViewById(R.id.rbCAU);
        tvresult=(TextView)findViewById(R.id.tvResult);
        btnConvert=(Button)findViewById(R.id.btn_convert);
    }

    public void submit(View view) {
        String s  = e1.getText().toString();
        double result = Double.parseDouble(s);
        if(ru.isChecked())
        {
            result = result / 83.42;
            tvresult.setText(String.valueOf(result));
        }
        else if(rc.isChecked())
        {
            result = result / 63.47;
            tvresult.setText(String.valueOf(result));
        }

    }
}
