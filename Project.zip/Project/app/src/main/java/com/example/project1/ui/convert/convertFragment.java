package com.example.project1.ui.convert;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.EditText;

import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.project1.R;

public class convertFragment extends Fragment {
    EditText e1;
    RadioButton ru, re;
    TextView tvResult;
    Button btnConverter;

    public convertFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater,  ViewGroup container,  Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.fragment_convert,container,false);

        e1 = (EditText)v.findViewById(R.id.eBDT);
        ru=(RadioButton)v.findViewById(R.id.rbUSD);
        re=(RadioButton)v.findViewById(R.id.rbCAD);
        tvResult = (TextView)v.findViewById(R.id.tvResult);
        btnConverter = (Button)v.findViewById(R.id.btn_convert);



            btnConverter.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String s = e1.getText().toString();
                    double result = Double.parseDouble(s);
                    if(ru.isChecked())
                    {
                        result = result/83.42;
                        tvResult.setText(String.valueOf(result));
                    }
                    else if(re.isChecked())
                    {
                        result = result/63.47;
                        tvResult.setText(String.valueOf(result));
                    }
                    else {
                        Toast.makeText(getContext(),"Select an option first", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        return v;
    }
}
