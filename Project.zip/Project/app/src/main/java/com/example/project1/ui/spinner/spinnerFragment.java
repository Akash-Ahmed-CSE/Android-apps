package com.example.project1.ui.spinner;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

import com.example.project1.R;

public class spinnerFragment extends Fragment {
    Spinner sp1,sp2;
    EditText ed1;
    Button b1;
    public spinnerFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater,  ViewGroup container,  Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.fragment_spinner,container,false);
        super.onCreate(savedInstanceState);

        ed1 = (EditText)v.findViewById(R.id.txtammount);
        sp1 = (Spinner)v.findViewById(R.id.spfrom);
        sp2 = (Spinner)v.findViewById(R.id.spto);
        b1 = (Button)v.findViewById(R.id.btn1);

        String[] from ={"Indian Rupee","USA dollar","Afgan Afghni","Algerian Dinar","Bajan dollar","Ghanaian Cedi","Colombian Peso","Bolivian Boliviano","Euro","Sol"};
        ArrayAdapter ad1 = new ArrayAdapter<String>(getActivity(),R.layout.support_simple_spinner_dropdown_item,from);
        sp1.setAdapter(ad1);


        String[] to ={"Bamgladeshi"};
        ArrayAdapter ad2 = new ArrayAdapter<String>(getActivity(),R.layout.support_simple_spinner_dropdown_item,to);
        sp2.setAdapter(ad2);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Double tot;
                Double ammount = Double.parseDouble(ed1.getText().toString());
                if(sp1.getSelectedItem().toString()== "Indian Rupee" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 0.0060;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "USA dollar" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 84.74;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "Afgan Afghni" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 1.10;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "Algerian Dinar" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 0.66;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "Bajan dollar" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 42.40;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "Ghanaian Cedi" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 14.53;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "Colombian Peso" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 0.023;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "Bolivian Boliviano" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 12.31;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "Euro" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 100.48;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }
                else if(sp1.getSelectedItem().toString()== "Sol" && sp2.getSelectedItem().toString()== "Bamgladeshi" )
                {
                    tot = ammount * 23.69;
                    Toast.makeText(getContext(),tot.toString(),Toast.LENGTH_SHORT).show();
                }



            }
        });




        return v;
    }
}



























