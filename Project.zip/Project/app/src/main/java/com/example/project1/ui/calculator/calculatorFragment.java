package com.example.project1.ui.calculator;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.widget.Button;
import android.widget.TextView;
import com.example.project1.R;

public class calculatorFragment extends Fragment {
    public calculatorFragment(){
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        final double[] in1 = {0};
        final double[] i2 = {0};
        final TextView edittext1;
        final boolean[] Add = new boolean[1];
        final boolean[] Sub = new boolean[1];
        final boolean[] Multiply = new boolean[1];
        final boolean[] Divide = new boolean[1];
        final boolean[] Remainder = new boolean[1];
        final boolean[] deci = new boolean[1];
        Button button_0, button_1, button_2, button_3, button_4, button_5, button_6, button_7, button_8, button_9, button_Add, button_Sub,
                button_Mul, button_Div, button_Equ, button_Del, button_Dot, button_Remainder;
        View view = inflater.inflate(R.layout.fragment_calculator,container,false);
        button_0 = view.findViewById(R.id.b0);
        button_1 = view.findViewById(R.id.b1);
        button_2 = view.findViewById(R.id.b2);
        button_3 = view.findViewById(R.id.b3);
        button_4 = view.findViewById(R.id.b4);
        button_5 = view.findViewById(R.id.b5);
        button_6 = view.findViewById(R.id.b6);
        button_7 = view.findViewById(R.id.b7);
        button_8 = view.findViewById(R.id.b8);
        button_9 = view.findViewById(R.id.b9);
        button_Dot = view.findViewById(R.id.bDot);
        button_Add = view.findViewById(R.id.badd);
        button_Sub = view.findViewById(R.id.bsub);
        button_Mul = view.findViewById(R.id.bmul);
        button_Div = view.findViewById(R.id.biv);
        button_Remainder = view.findViewById(R.id.BRemain);
        button_Del = view.findViewById(R.id.buttonDel);
        button_Equ = view.findViewById(R.id.buttoneql);

        edittext1 = view.findViewById(R.id.display);

        button_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "1");
            }
        });

        button_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "2");
            }
        });

        button_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "3");
            }
        });

        button_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "4");
            }
        });

        button_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "5");
            }
        });

        button_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "6");
            }
        });

        button_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "7");
            }
        });

        button_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "8");
            }
        });

        button_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "9");
            }
        });

        button_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText(edittext1.getText() + "0");
            }
        });

        button_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1[0] = Float.parseFloat(edittext1.getText() + "");
                    Add[0] = true;
                    deci[0] = false;
                    edittext1.setText(null);
                }
            }
        });

        button_Sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1[0] = Float.parseFloat(edittext1.getText() + "");
                    Sub[0] = true;
                    deci[0] = false;
                    edittext1.setText(null);
                }
            }
        });

        button_Mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1[0] = Float.parseFloat(edittext1.getText() + "");
                    Multiply[0] = true;
                    deci[0] = false;
                    edittext1.setText(null);
                }
            }
        });

        button_Div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1[0] = Float.parseFloat(edittext1.getText() + "");
                    Divide[0] = true;
                    deci[0] = false;
                    edittext1.setText(null);
                }
            }
        });

        button_Remainder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1[0] = Float.parseFloat(edittext1.getText() + "");
                    Remainder[0] = true;
                    deci[0] = false;
                    edittext1.setText(null);
                }
            }
        });

        button_Equ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Add[0] || Sub[0] || Multiply[0] || Divide[0] || Remainder[0]) {
                    i2[0] = Float.parseFloat(edittext1.getText() + "");
                }

                if (Add[0]) {

                    edittext1.setText(in1[0] + i2[0] + "");
                    Add[0] = false;
                }

                if (Sub[0]) {

                    edittext1.setText(in1[0] - i2[0] + "");
                    Sub[0] = false;
                }

                if (Multiply[0]) {
                    edittext1.setText(in1[0] * i2[0] + "");
                    Multiply[0] = false;
                }

                if (Divide[0]) {
                    edittext1.setText(in1[0] / i2[0] + "");
                    Divide[0] = false;
                }
                if (Remainder[0]) {
                    edittext1.setText(in1[0] % i2[0] + "");
                    Remainder[0] = false;
                }
            }
        });

        button_Del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText("");
                in1[0] = 0.0;
                i2[0] = 0.0;
            }
        });

        button_Dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (deci[0]) {
                    //do nothing or you can show the error
                } else {
                    edittext1.setText(edittext1.getText() + ".");
                    deci[0] = true;
                }

            }
        });

        return view;
    }
}
